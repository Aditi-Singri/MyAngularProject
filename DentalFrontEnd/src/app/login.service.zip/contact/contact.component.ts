import { NgForm } from '@angular/forms';
import { Component , OnInit , ViewChild} from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit{
  formvalid=true;
  @ViewChild('myform') form: NgForm
  constructor(private http: HttpClient){

  }
  ngOnInit() {
    // this.onSubmit()
  }
  
  onSubmit(contactinfo: {name : string , email : string , number : string , date :string , time:string})
  {
    this.http.post('https://angular-app-9d307-default-rtdb.firebaseio.com/contact.json',contactinfo)
    .subscribe((res)=>{
      console.log(res)
    })
    console.log(this.form)
    if(this.form.valid)
    {
      alert("Appointment completed Successfully !!")
      this.form.reset()
    }
    console.log(this.formvalid)
  }
  
}
