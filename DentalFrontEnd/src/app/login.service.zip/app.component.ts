import { Component , OnChanges, OnInit , ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { LoginService } from './login.service';
import { LoginComponent } from './login/login.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})



export class AppComponent implements OnInit {
  
 @ViewChild('loggedIn') isLoggedIn:boolean;
 
  title = 'my_first_app';
  item_name= "login/signup"
  loggedin: boolean
  // x=false;
  // sections=true
  // contact=false;
  // SignUp=false;
  ImagePath: string;
  // yhide:true;
  constructor(private activatedroute:ActivatedRoute , private loginservice: LoginService , private router : Router){
    this.ImagePath = '../assets/img/icons8-user-30.png'
  }
  ngOnInit(){
    // this.activatedroute.fragment.subscribe((value)=>{
    //   console.log("value")
    //   this.jumpTo(value)
    // });
    
  }
  
  // jumpTo(section){
  //   document.getElementById(section).scrollIntoView({behavior:'smooth'});
  // }
  openlogin(){
    if(this.item_name== "login/signup"){
      // this.x=true
      // this.sections=false
      // this.contact=false
      // this.SignUp=false
      this.router.navigate(['Login'])

    }
    else{
      // this.contact=false;
      // this.sections=true;
      // this.x=false;
      // this.SignUp=false;
      this.loginservice.loggedIn=false
      this.item_name= "login/signup"
      this.router.navigate(['Home'])
    }
  }
    openloginbefore(){
      if(!this.loginservice.loggedIn){
        // this.x=true
        // this.sections=false
        // this.contact=false
        this.router.navigate(['Login'])

      }
    }
    
  

  change(event){
    
    this.item_name="logout"
  }
  // opensignuppage(event){
  //      this.SignUp=true;
  //      this.x=false;
  //      this.sections=false;
  //  }
  //  change1(event){
    
  //   this.SignUp=false;
  //   this.x=true;
  //   this.sections=false;
  //  }
  // openlogout(){
  //   // this.yhide=this.child.loggedin
  //   this.x=true
  //   // console.log(this.yhide)
  // }
  // ngDoCheck (){}

}
