import { NgForm } from '@angular/forms';
import { Component , OnInit , ComponentRef, Output, EventEmitter, ViewChild, ElementRef} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../login.service';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // @ViewChild('myform') form: NgForm
  @ViewChild('mail') mail: ElementRef;
  @ViewChild('pass') pass: ElementRef;
  @Output('newEventItem') newItemEvent = new EventEmitter<boolean>();

  addNewItem() {
    this.newItemEvent.emit();
  }
  @Output('newEventItem1') newItemEvent1 = new EventEmitter<boolean>();

  addNewItem1() {
    this.newItemEvent1.emit();
  }
  
  // loggedin=false;
  // loginpage = LoginComponent
  all_users=[]
  mailid:string
  password:string
  validuser:boolean
 constructor(private router:Router, private loginService:LoginService,private http : HttpClient){

 }
  ngOnInit() {
    // this.hidelogin();
  }
  loggedinpage(){
    // console.log(this.checkvaliduser());
    // console.log(this.all_users)
    this.mailid =this.mail.nativeElement.value 
    this.password= this.pass.nativeElement.value
    console.log(this.mailid , this.password)
    this.checkvaliduser()
    
    // this.passtoparent();
  }
  opensignup(){
  //   // this.loginService.loggedIn = true;
        //this.addNewItem1();
        this.router.navigate(['Signup']);

   }
   checkvaliduser(){
    this.http.get('https://angular-app-9d307-default-rtdb.firebaseio.com/signup.json')
    .pipe(map((res) =>{
      const users = [];
      for(const key in res)
      {
        if(res.hasOwnProperty(key))
          users.push({...res[key], id:key})
      }
      return users;
    }))
    .subscribe((users)=>{
      console.log(users);
      // this.all_users=users
      // console.log(this.all_users);
      for(let val of users)
      {
        if(val.email==this.mailid && val.pass==this.password)
            this.validuser = true
      }
      console.log(this.validuser)
      if(this.validuser)
    {
      this.loginService.loggedIn = true;
      this.addNewItem();
      this.router.navigate(['Home']);
    }
    else
      alert('invalid user id & password')
    })
    // return this.validuser
   }
  // passtoparent(){
  //   return true;
  // }
}

