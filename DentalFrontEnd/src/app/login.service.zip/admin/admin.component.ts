import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { patients } from '../model/patients';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  
  @ViewChild('date') date: ElementRef;
  appointmentDate:string
  allPatients:patients[]=[];
  number_of_patients=-1
  constructor(private router:Router , private http : HttpClient) { }

  ngOnInit(): void {
  }
  displayPatients(){
    this.appointmentDate=this.date.nativeElement.value
    this.http.get('https://angular-app-9d307-default-rtdb.firebaseio.com/contact.json')
    .pipe(map((res) =>{
      const Patients = [];
      for(const key in res)
      {
        if(res.hasOwnProperty(key))
        Patients.push({...res[key], id:key})
      }
      return Patients;
    }))
    .subscribe((Patients)=>{
      
      for(let val of Patients)
      {
        if(val.date==this.appointmentDate)
            this.allPatients.push(val)
      }
      this.number_of_patients=this.allPatients.length;
    })
    
   }
}
