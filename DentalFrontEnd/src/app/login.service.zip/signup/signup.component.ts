import { HttpClient } from '@angular/common/http';
import { Component, OnInit, EventEmitter , Output, ElementRef, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})

export class SignupComponent implements OnInit {
  @ViewChild('pass') pass: ElementRef;
  @ViewChild('confirmpass') confirmpass: ElementRef;
  @ViewChild('email') email: ElementRef;
  validpasswords:boolean
  existinguser:boolean
  @Output('newEventItemSignup') newItemEvent = new EventEmitter<boolean>();

  addNewItem() {
    this.newItemEvent.emit();
  }
  constructor(private http : HttpClient, private router:Router) { }

  ngOnInit() {
  }
  checkpasswords(){
    if(this.pass.nativeElement.value===this.confirmpass.nativeElement.value)
      this.validpasswords=true
    else
      this.validpasswords=false
  }
  insertnewusers(signupinfo){
    this.http.post('https://angular-app-9d307-default-rtdb.firebaseio.com/signup.json',signupinfo)
    .subscribe((res)=>{
      console.log(res)
    })
    alert("registration succesfull , login to proceed")
    this.router.navigate(['Login'])

     //this.addNewItem();
    
   }
  onsignningup(signupinfo: {name : string , email : string , mobile : string , pass :string})
  {

    this.http.get('https://angular-app-9d307-default-rtdb.firebaseio.com/signup.json')
    .pipe(map((res) =>{
      const users = [];
      for(const key in res)
      {
        if(res.hasOwnProperty(key))
          users.push({...res[key], id:key})
      }
      return users;
    }))
    .subscribe((users)=>{
      console.log(users);
      this.existinguser = false
      for(let val of users)
      {
        if(val.email==this.email.nativeElement.value)
            this.existinguser = true
        
      }
      if(!this.existinguser)
    {
      this.insertnewusers(signupinfo)
    }
    else
    {
      this.router.navigate(['Signup'])
      alert('user already existing')
    }
    })
   }
 
  }


  
