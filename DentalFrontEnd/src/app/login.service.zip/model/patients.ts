export class patients{
    name:string;
    email:string;
    number:string;
    date :string;
    time:string;
}